require_relative 'config/db_connection.rb'

DBConnection.reset
